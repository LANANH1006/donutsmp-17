package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.literal;

/** /settings kieu DonutSMP: moi nguoi tu bat/tat tung thiet lap (luu file). */
public class Settings {
    static final String[] KEYS = {"tpa", "pay", "botchat", "trade", "kills", "sidebar", "sound"};
    static final String[] NAMES = {"Yêu cầu TPA", "Nhận tiền /pay", "Chat & hoạt động chợ", "Thông báo mua/bán", "Thông báo Kill", "Bảng bên phải", "Âm thanh mua/bán"};
    static final Item[] ICONS = {Items.ENDER_PEARL, Items.GOLD_INGOT, Items.PAPER, Items.EMERALD, Items.DIAMOND_SWORD, Items.OAK_SIGN, Items.NOTE_BLOCK};
    static final String[] DESC = {
        "§7Cho phép người khác gửi /tpa /tpahere cho bạn",
        "§7Cho phép người khác chuyển tiền cho bạn bằng /pay",
        "§7Hiện chat + tin order/ah của người chơi khác trong chat",
        "§7Báo khi có người mua đồ /ah hoặc giao hàng cho order của bạn",
        "§7Hiện thông báo khi bạn hạ gục người chơi / bot",
        "§7Bảng thông tin bên phải màn hình (giống /sidebar)",
        "§7Tiếng 'ting' khi mua / bán / nhận tiền"};

    /** Mac dinh tat ca BAT. */
    static boolean on(UUID id, String key) {
        if (key.equals("sidebar")) return !Hud.HIDDEN.contains(id);
        if (DonutLike.save.psettings == null) return true;
        Boolean b = DonutLike.save.psettings.get(id + "|" + key);
        return b == null || b;
    }

    static void toggle(UUID id, String key) {
        boolean now = !on(id, key);
        if (key.equals("sidebar")) { if (now) Hud.HIDDEN.remove(id); else Hud.HIDDEN.add(id); return; }
        if (DonutLike.save.psettings == null) DonutLike.save.psettings = new HashMap<>();
        DonutLike.save.psettings.put(id + "|" + key, now);
    }

    static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (sid, inv, pl) -> new Gui(sid, inv, new SimpleInventory(27), pl.getUuid()), Text.literal("Settings")));
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        for (String n : new String[]{"settings", "setting"})
            d.register(literal(n).executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; }));
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final UUID id;

        Gui(int sid, PlayerInventory pinv, SimpleInventory inv, UUID id) {
            super(ScreenHandlerType.GENERIC_9X3, sid, pinv, inv, 3);
            this.inv = inv; this.id = id;
            refresh();
        }

        void refresh() {
            ShopHandler.fill(inv);
            for (int i = 0; i < KEYS.length; i++) {
                boolean v = on(id, KEYS[i]);
                inv.setStack(10 + i, ShopHandler.icon(ICONS[i], (v ? "§a" : "§c") + NAMES[i], DESC[i],
                    v ? "§aĐang BẬT" : "§cĐang TẮT", "§eClick để " + (v ? "tắt" : "bật")));
                inv.setStack(19 + i, ShopHandler.icon(v ? Items.LIME_DYE : Items.GRAY_DYE, (v ? "§aBẬT" : "§cTẮT") + " §7- " + NAMES[i], "§eClick để đổi"));
            }
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && slot >= 0 && slot < 27) {
                int idx = (slot >= 19 && slot < 19 + KEYS.length) ? slot - 19 : (slot >= 10 && slot < 10 + KEYS.length) ? slot - 10 : -1;
                if (idx >= 0) { toggle(sp.getUuid(), KEYS[idx]); ShopHandler.ting(sp); refresh(); }
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
