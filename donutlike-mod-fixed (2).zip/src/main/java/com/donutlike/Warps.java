package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;

import static net.minecraft.server.command.CommandManager.literal;

/** /rtp (GUI: co = overworld, netherrack = nether, end stone = end, tim cho tung tick cho muot), /warp afk, khu spawn + khu AFK. */
public class Warps {

    static final int AFK_X = -9000, AFK_Y = 200, AFK_Z = 9000;

    // ===================== RTP =====================
    static class Search { ServerPlayerEntity p; ServerWorld w; String dim; int tries; }
    static final Map<UUID, Search> SEARCH = new HashMap<>();

    static void openRtp(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new RtpGui(id, inv, new SimpleInventory(27)), Text.literal("Random Teleport")));
    }

    static class RtpGui extends GenericContainerScreenHandler {
        RtpGui(int id, PlayerInventory pinv, SimpleInventory inv) {
            super(ScreenHandlerType.GENERIC_9X3, id, pinv, inv, 3);
            ShopHandler.fill(inv);
            inv.setStack(11, ShopHandler.icon(Items.GRASS_BLOCK, "§a§lOverworld", "§7RTP ngẫu nhiên", "§eClick để dịch chuyển"));
            inv.setStack(13, ShopHandler.icon(Items.NETHERRACK, "§c§lNether", "§7RTP ngẫu nhiên", "§eClick để dịch chuyển"));
            inv.setStack(15, ShopHandler.icon(Items.END_STONE, "§e§lEnd", "§7RTP ngẫu nhiên", "§eClick để dịch chuyển"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && button == 0) {
                String dim = slot == 11 ? "overworld" : slot == 13 ? "nether" : slot == 15 ? "end" : null;
                if (dim != null) ShopHandler.later(sp, () -> { sp.closeHandledScreen(); startRtp(sp, dim); });
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    static void startRtp(ServerPlayerEntity p, String dim) {
        if (ExtraCommands.blocked(p)) return;
        long now = DonutLike.tick;
        Long cd = ExtraCommands.RTP_CD.get(p.getUuid());
        if (cd != null && now < cd) { DonutLike.msg(p, "§cChờ " + ((cd - now) / 20) + " giây nữa."); return; }
        MinecraftServer s = DonutLike.SERVER;
        ServerWorld w = dim.equals("nether") ? s.getWorld(World.NETHER) : dim.equals("end") ? s.getWorld(World.END) : s.getOverworld();
        if (w == null) { DonutLike.msg(p, "§cThế giới này không tồn tại."); return; }
        Search se = new Search();
        se.p = p; se.w = w; se.dim = dim;
        SEARCH.put(p.getUuid(), se);
        p.sendMessage(Text.literal("§eĐang tìm vị trí an toàn..."), true);
    }

    /** moi tick: moi nguoi thu 1 vi tri (khong dung hinh), tim duoc thi dich chuyen */
    static void tick(MinecraftServer s) {
        if (SEARCH.isEmpty()) return;
        for (Search se : new ArrayList<>(SEARCH.values())) {
            ServerPlayerEntity p = se.p;
            if (p.isRemoved() || Duels.inDuel(p) || Combat.tagged(p)) { SEARCH.remove(p.getUuid()); continue; }
            BlockPos found = try1(se);
            se.tries++;
            if (found != null) {
                SEARCH.remove(p.getUuid());
                go(p, se.w, found);
            } else if (se.tries >= 60) {
                SEARCH.remove(p.getUuid());
                DonutLike.msg(p, "§cKhông tìm được chỗ hợp lệ, thử lại.");
            }
        }
    }

    static BlockPos try1(Search se) {
        ServerWorld w = se.w;
        Random r = DonutLike.R;
        int range, min;
        switch (se.dim) {
            case "nether" -> { min = 200; range = 1800; }
            case "end" -> { min = 1200; range = 3500; }
            default -> { min = 0; range = 5000; }
        }
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = se.dim.equals("overworld") ? r.nextInt(range) : min + r.nextInt(range - min);
        int x = (int) (Math.cos(ang) * dist), z = (int) (Math.sin(ang) * dist);
        w.getChunk(x >> 4, z >> 4);
        switch (se.dim) {
            case "nether" -> {
                for (int y = 100; y > 32; y--) {
                    BlockPos f = new BlockPos(x, y - 1, z);
                    BlockState below = w.getBlockState(f);
                    if (below.isSolidBlock(w, f) && w.getFluidState(f).isEmpty() && w.getBlockState(f.up()).isAir() && w.getBlockState(f.up(2)).isAir()
                            && !below.isOf(Blocks.MAGMA_BLOCK) && w.getFluidState(f.up()).isEmpty()) return f.up();
                }
                return null;
            }
            case "end" -> {
                int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
                if (y <= w.getBottomY() + 2) return null;
                BlockPos f = new BlockPos(x, y - 1, z);
                return w.getBlockState(f).isOf(Blocks.END_STONE) ? f.up() : null;
            }
            default -> {
                int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                BlockPos f = new BlockPos(x, y - 1, z);
                BlockState st = w.getBlockState(f);
                if (st.isAir() || !w.getFluidState(f).isEmpty() || !w.getFluidState(f.up()).isEmpty()) return null;
                if (st.isOf(Blocks.LAVA) || st.isOf(Blocks.CACTUS) || st.isOf(Blocks.MAGMA_BLOCK)) return null;
                return f.up();
            }
        }
    }

    static void go(ServerPlayerEntity p, ServerWorld w, BlockPos at) {
        ServerWorld from = (ServerWorld) p.getEntityWorld();
        from.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.8, 0.4, 0.3);
        ExtraCommands.tp(p, w, at.getX() + 0.5, at.getY(), at.getZ() + 0.5);
        w.spawnParticles(ParticleTypes.REVERSE_PORTAL, at.getX() + 0.5, at.getY() + 1, at.getZ() + 0.5, 40, 0.4, 0.8, 0.4, 0.3);
        w.playSound(null, at.getX() + 0.5, at.getY(), at.getZ() + 0.5, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1f, 1f);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 100, 4));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 100, 0));
        ExtraCommands.RTP_CD.put(p.getUuid(), DonutLike.tick + 20 * 30);
        DonutLike.msg(p, "§aĐã RTP tới " + at.getX() + " " + at.getY() + " " + at.getZ());
    }

    // ===================== /warp =====================
    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("warp")
            .executes(c -> { DonutLike.msg(c.getSource().getPlayerOrThrow(), "§eWarps: §f/warp afk, /warp spawn"); return 1; })
            .then(literal("afk").executes(c -> {
                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                if (ExtraCommands.blocked(p)) return 0;
                ServerWorld w = c.getSource().getServer().getOverworld();
                ensureAfk(w);
                ExtraCommands.tp(p, w, AFK_X + 0.5, AFK_Y + 1, AFK_Z + 0.5);
                DonutLike.msg(p, "§aĐã tới khu AFK. Gõ /spawn để về lại.");
                return 1;
            }))
            .then(literal("spawn").executes(c -> { DonutLike.runCmd(c.getSource(), "spawn"); return 1; })));
    }

    static void ensureAfk(ServerWorld w) {
        if (!w.getBlockState(new BlockPos(AFK_X, AFK_Y, AFK_Z)).isAir()) return;
        buildAfk(w);
    }

    // ===================== xay dung =====================
    static void set(ServerWorld w, int x, int y, int z, Block b) { DonutLike.set(w, new BlockPos(x, y, z), b); }

    /** Khu AFK: phong kinh 21x21, san gach, den bien. */
    static void buildAfk(ServerWorld w) {
        for (int dx = -10; dx <= 10; dx++) for (int dz = -10; dz <= 10; dz++) {
            boolean edge = Math.abs(dx) == 10 || Math.abs(dz) == 10;
            set(w, AFK_X + dx, AFK_Y, AFK_Z + dz, (Math.abs(dx) + Math.abs(dz)) % 4 == 0 ? Blocks.SEA_LANTERN : Blocks.PURPUR_BLOCK);
            for (int dy = 1; dy <= 6; dy++) set(w, AFK_X + dx, AFK_Y + dy, AFK_Z + dz, edge ? Blocks.PURPLE_STAINED_GLASS : Blocks.AIR);
            set(w, AFK_X + dx, AFK_Y + 7, AFK_Z + dz, Blocks.PURPLE_STAINED_GLASS);
        }
        set(w, AFK_X, AFK_Y, AFK_Z, Blocks.AMETHYST_BLOCK);
    }

    /** Khu spawn kieu DonutSMP cu: quang truong tron ban kinh 22, vong den, 4 cot, bon cong vom. */
    static void buildSpawn(ServerWorld w, BlockPos c) {
        int R = 22;
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > R) continue;
            Block floor = d < 4 ? Blocks.GOLD_BLOCK : d < 6 ? Blocks.QUARTZ_BLOCK : (d > R - 1.5 ? Blocks.POLISHED_BLACKSTONE_BRICKS
                    : ((int) d % 5 == 0 ? Blocks.SEA_LANTERN : Blocks.STONE_BRICKS));
            set(w, c.getX() + dx, c.getY() - 1, c.getZ() + dz, floor);
            for (int dy = 0; dy <= 12; dy++) set(w, c.getX() + dx, c.getY() + dy, c.getZ() + dz, Blocks.AIR);
        }
        // 4 cot goc + den
        int[][] pil = {{14, 14}, {-14, 14}, {14, -14}, {-14, -14}};
        for (int[] q : pil) {
            for (int dy = 0; dy < 7; dy++) set(w, c.getX() + q[0], c.getY() + dy, c.getZ() + q[1], Blocks.QUARTZ_PILLAR);
            set(w, c.getX() + q[0], c.getY() + 7, c.getZ() + q[1], Blocks.SEA_LANTERN);
        }
        // bon cong vom (bac/nam/dong/tay)
        int[][] gate = {{0, R - 2, 0}, {0, -(R - 2), 0}, {R - 2, 0, 1}, {-(R - 2), 0, 1}};
        for (int[] g : gate) {
            for (int s = -3; s <= 3; s += 6) for (int dy = 0; dy < 6; dy++)
                set(w, c.getX() + g[0] + (g[2] == 0 ? s : 0), c.getY() + dy, c.getZ() + g[1] + (g[2] == 1 ? s : 0), Blocks.POLISHED_BLACKSTONE_BRICKS);
            for (int s = -3; s <= 3; s++)
                set(w, c.getX() + g[0] + (g[2] == 0 ? s : 0), c.getY() + 6, c.getZ() + g[1] + (g[2] == 1 ? s : 0), Blocks.POLISHED_BLACKSTONE_BRICKS);
        }
        // bieu tuong "donut" o giua: vong amethyst quanh khoi vang
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d >= 1.2 && d <= 2.3) set(w, c.getX() + dx, c.getY(), c.getZ() + dz, Blocks.AMETHYST_BLOCK);
        }
    }
}
