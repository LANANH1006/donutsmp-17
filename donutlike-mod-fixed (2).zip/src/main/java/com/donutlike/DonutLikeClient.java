package com.donutlike;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

/**
 * Client: hien gia ban cua vat pham khi re chuot vao (moi inventory, ke ca trong Shulker).
 * 1 cuc dat = $1, 2 cuc = $2 ... Tien hien dang 1 / 100K / 1M / 1B / 1T.
 * Can cai mod nay o CA client lan server (singleplayer thi tu co).
 */
public class DonutLikeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Xo nuoc Amethyst: client KHONG tu doi thanh xo rong (vanilla du doan sai). Chi gui goi tin len server,
        // server (Tools.bucket) moi xu ly muc/dat nuoc va giu nguyen xo.
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient() && Tools.kind(player.getStackInHand(hand)).equals("bucket")) return ActionResult.SUCCESS;
            return ActionResult.PASS;
        });
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (stack == null || stack.isEmpty()) return;
            double v = Prices.stack(stack);
            if (v <= 0) return;
            lines.add(Text.literal("§6Sell: §a$" + Prices.money(v)));
        });
    }
}
