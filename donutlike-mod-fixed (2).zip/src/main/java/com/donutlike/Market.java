package com.donutlike;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.CommandSource;
import java.util.concurrent.CompletableFuture;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Cho do (AH) + Order (thu mua) do NGUOI CHOI thuc su dang/giao dich.
 * - /ah, /ah sell <gia>, /ah search <ten>   (toi da MAX_LISTINGS mon / nguoi)
 * - /orders, /orders create <item> <sl> <gia/item>  (gia mua cao nhat len trang 1)
 */
public class Market {
    static int maxListings() { return Admin.inum("max_listings"); }
    static int maxOrders() { return Admin.inum("max_orders"); }
    static final int PER_PAGE = 45;

    static class Listing {
        UUID seller; String sellerName; ItemStack stack; double price; long created;
        long vid = -1; // so thu tu hang ao (/ah vo han trang)
        long buyAt = 0; // thoi diem bot se mua (5-10s sau khi dang)
        boolean bot; // hang cua bot (khong luu file, khong tra tien cho ai)
        Listing(UUID s, String n, ItemStack st, double p) { seller = s; sellerName = n; stack = st; price = p; created = System.currentTimeMillis(); }
    }
    static class Order {
        UUID buyer; String buyerName; ItemStack template; long remaining; double perItem; long created;
        long stored = 0; // do da duoc giao, nam trong order cho chu order lay ve
        Order(UUID b, String n, ItemStack t, long r, double p) { buyer = b; buyerName = n; template = t; remaining = r; perItem = p; created = System.currentTimeMillis(); }
    }
    static class SavedOrder { String buyer, buyerName, nbt; long remaining, stored, created; double per; }

    static String num(long v) { return String.format("%,d", v); }
    /** Dang luu xuong file (SNBT) */
    static class SavedListing { String seller, sellerName, nbt; double price; long created; }

    static final List<Listing> LISTINGS = new ArrayList<>();
    static final List<Order> ORDERS = new ArrayList<>();

    // ===== init / persistence =====
    static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(Market::restore);
        // order duoc luu file (kem do da giao), nguoi dat offline van nhan do khi quay lai
    }

    static void restore(net.minecraft.server.MinecraftServer s) {
        DonutLike.SERVER = s;
        LISTINGS.clear();
        ORDERS.clear();
        if (DonutLike.save.orders != null) for (SavedOrder so : DonutLike.save.orders) {
            ItemStack st = ItemIO.decode(so.nbt);
            if (st.isEmpty()) continue;
            Order o = new Order(UUID.fromString(so.buyer), so.buyerName, st, so.remaining, so.per);
            o.stored = so.stored; o.created = so.created;
            ORDERS.add(o);
        }
        if (DonutLike.save.listings == null) return;
        for (SavedListing sl : DonutLike.save.listings) {
            ItemStack st = ItemIO.decode(sl.nbt);
            if (st.isEmpty()) continue;
            Listing l = new Listing(UUID.fromString(sl.seller), sl.sellerName, st, sl.price);
            l.created = sl.created;
            LISTINGS.add(l);
        }
    }

    /** goi truoc moi lan doSave() */
    static void snapshot() {
        if (DonutLike.SERVER == null) return;
        List<SavedListing> out = new ArrayList<>();
        for (Listing l : LISTINGS) {
            String nbt = ItemIO.encode(l.stack);
            if (nbt == null) continue;
            SavedListing sl = new SavedListing();
            sl.seller = l.seller.toString(); sl.sellerName = l.sellerName; sl.nbt = nbt; sl.price = l.price; sl.created = l.created;
            out.add(sl);
        }
        DonutLike.save.listings = out;
        List<SavedOrder> oo = new ArrayList<>();
        for (Order o : ORDERS) {
            String nbt = ItemIO.encode(o.template);
            if (nbt == null) continue;
            SavedOrder so = new SavedOrder();
            so.buyer = o.buyer.toString(); so.buyerName = o.buyerName; so.nbt = nbt;
            so.remaining = o.remaining; so.stored = o.stored; so.per = o.perItem; so.created = o.created;
            oo.add(so);
        }
        DonutLike.save.orders = oo;
    }

    static void refundOrders(UUID buyer, boolean notify) {
        Iterator<Order> it = ORDERS.iterator();
        while (it.hasNext()) {
            Order o = it.next();
            if (!o.buyer.equals(buyer)) continue;
            DonutLike.add(buyer, o.perItem * o.remaining);
            it.remove();
        }
    }

    /** Khi tat server: hoan tien tat ca order dang cho (order khong luu file, tranh mat tien giu) */
    static void refundAll() {
        for (Order o : new ArrayList<>(ORDERS)) DonutLike.add(o.buyer, o.perItem * o.remaining);
        ORDERS.clear();
    }

    static long countListings(UUID u) { return LISTINGS.stream().filter(l -> l.seller.equals(u)).count(); }
    static long countOrders(UUID u) { return ORDERS.stream().filter(o -> o.buyer.equals(u)).count(); }

    // ===== goi y ten item cho /ah <item> va /order <item> =====
    static List<String> ITEM_IDS = null;
    static CompletableFuture<Suggestions> suggestItems(CommandContext<ServerCommandSource> c, SuggestionsBuilder b) {
        if (ITEM_IDS == null) {
            List<String> l = new ArrayList<>();
            for (var id : Registries.ITEM.getIds()) l.add(id.getPath());
            Collections.sort(l);
            ITEM_IDS = l;
        }
        return CommandSource.suggestMatching(ITEM_IDS, b);
    }

    // ===== lenh =====
    static void register(CommandDispatcher<ServerCommandSource> d, CommandRegistryAccess ra) {
        d.register(literal("ah").requires(s -> Admin.on("ah"))
            .executes(c -> { openAh(c.getSource().getPlayerOrThrow(), 0, null, 0); return 1; })
            .then(literal("sell").then(argument("price", DoubleArgumentType.doubleArg(0.01)).executes(c -> sell(c.getSource().getPlayerOrThrow(), DoubleArgumentType.getDouble(c, "price")))))
            .then(literal("page").then(argument("n", IntegerArgumentType.integer(1, 1_000_000_000))
                .executes(c -> { openAh(c.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(c, "n") - 1, null, 0); return 1; })
                .then(argument("item", StringArgumentType.greedyString()).suggests(Market::suggestItems).executes(c -> {
                    openAh(c.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(c, "n") - 1, StringArgumentType.getString(c, "item").toLowerCase().trim(), 0); return 1; }))))
            .then(literal("search").then(argument("name", StringArgumentType.greedyString()).executes(c -> {
                openAh(c.getSource().getPlayerOrThrow(), 0, StringArgumentType.getString(c, "name").toLowerCase(), 0); return 1; })))
            // /ah <vat pham>  vd: /ah elytra
            .then(argument("item", StringArgumentType.greedyString()).suggests(Market::suggestItems).executes(c -> {
                openAh(c.getSource().getPlayerOrThrow(), 0, StringArgumentType.getString(c, "item").toLowerCase().trim(), 0); return 1; })));
        // alias cu
        d.register(literal("sell").requires(s -> Admin.on("ah")).then(argument("price", DoubleArgumentType.doubleArg(0.01)).executes(c -> sell(c.getSource().getPlayerOrThrow(), DoubleArgumentType.getDouble(c, "price")))));
        d.register(ordersTree("orders", ra));
        d.register(ordersTree("order", ra));
    }

    static LiteralArgumentBuilder<ServerCommandSource> ordersTree(String name, CommandRegistryAccess ra) {
        return literal(name).requires(s -> Admin.on("orders"))
            .executes(c -> { openOrders(c.getSource().getPlayerOrThrow(), 0); return 1; })
            // /order <vat pham>  vd: /order elytra  -> chi hien order cua vat pham do (de giao hang)
            .then(argument("item", StringArgumentType.greedyString()).suggests(Market::suggestItems).executes(c -> {
                openOrders(c.getSource().getPlayerOrThrow(), 0, StringArgumentType.getString(c, "item").toLowerCase().trim()); return 1; }))
            .then(literal("page").then(argument("n", IntegerArgumentType.integer(1, 1_000_000_000))
                .executes(c -> { openOrders(c.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(c, "n") - 1, null, 0); return 1; })
                .then(argument("item", StringArgumentType.greedyString()).suggests(Market::suggestItems).executes(c -> {
                    openOrders(c.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(c, "n") - 1, StringArgumentType.getString(c, "item").toLowerCase().trim(), 0); return 1; }))))
            .then(literal("create")
                .then(argument("item", ItemStackArgumentType.itemStack(ra))
                .then(argument("amount", LongArgumentType.longArg(1, 100_000_000_000_000_000L))
                .then(argument("price", DoubleArgumentType.doubleArg(0.01)).executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    ItemStack tpl = ItemStackArgumentType.getItemStackArgument(c, "item").createStack(1, false);
                    return createOrder(p, tpl, LongArgumentType.getLong(c, "amount"), DoubleArgumentType.getDouble(c, "price"));
                })))));
    }

    static int sell(ServerPlayerEntity p, double price) {
        ItemStack hand = p.getMainHandStack();
        if (hand.isEmpty()) { DonutLike.msg(p, "§cHãy cầm vật phẩm muốn bán trên tay."); return 0; }
        if (countListings(p.getUuid()) >= maxListings()) { DonutLike.msg(p, "§cBạn chỉ được đăng tối đa " + maxListings() + " món cùng lúc."); return 0; }
        LISTINGS.add(new Listing(p.getUuid(), p.getName().getString(), hand.copy(), price));
        p.setStackInHand(Hand.MAIN_HAND, ItemStack.EMPTY);
        DonutLike.msg(p, "§aĐã đăng bán lên /ah giá $" + DonutLike.fmt(price) + " §7(" + countListings(p.getUuid()) + "/" + maxListings() + ")");
        return 1;
    }

    static int createOrder(ServerPlayerEntity p, ItemStack tpl, long amount, double per) {
        if (countOrders(p.getUuid()) >= maxOrders()) { DonutLike.msg(p, "§cTối đa " + maxOrders() + " order cùng lúc."); return 0; }
        double total = per * amount;
        if (DonutLike.bal(p.getUuid()) < total) { DonutLike.msg(p, "§cBạn cần $" + DonutLike.fmt(total) + " để đặt order này."); return 0; }
        DonutLike.add(p.getUuid(), -total); // giu tien (escrow)
        ORDERS.add(new Order(p.getUuid(), p.getName().getString(), tpl, amount, per));
        DonutLike.msg(p, "§aĐã đặt order " + num(amount) + "x " + tpl.getName().getString() + " ($" + DonutLike.fmt(per) + "/cái). Tiền đã được giữ lại, chờ người chơi khác hoặc bot giao hàng, đồ sẽ nằm trong order (/orders → \"Order của bạn\" để lấy).");
        double unit = Prices.unit(tpl.getItem());
        if (Admin.on("bots") && unit > 0 && per < unit * FakeMarket.MIN_RATIO)
            DonutLike.msg(p, "§eGiá hơi thấp, bot chỉ giao khi giá ≥ $" + DonutLike.fmt(unit * FakeMarket.MIN_RATIO) + "/cái (người chơi thật vẫn có thể giao).");
        return 1;
    }

    // ===== GUI helpers =====
    static ItemStack named(net.minecraft.item.Item it, String name, String... lore) {
        ItemStack s = new ItemStack(it);
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name));
        if (lore.length > 0) {
            List<Text> l = new ArrayList<>();
            for (String x : lore) l.add(Text.literal(x));
            s.set(DataComponentTypes.LORE, new LoreComponent(l));
        }
        return s;
    }

    static void openAh(ServerPlayerEntity p, int page, String filter, int sort) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new AhGui(id, inv, new SimpleInventory(54), pl.getUuid(), page, filter, sort),
            Text.literal("Auction House" + (filter != null ? " [" + filter + "]" : ""))));
    }

    static void openOrders(ServerPlayerEntity p, int page) { openOrders(p, page, null); }

    static void openOrders(ServerPlayerEntity p, int page, String filter) { openOrders(p, page, filter, 0); }

    static void openOrders(ServerPlayerEntity p, int page, String filter, int sort) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new OrderGui(id, inv, new SimpleInventory(54), pl.getUuid(), page, filter, sort),
            Text.literal("@me".equals(filter) ? "Order của bạn" : "Orders" + (filter != null ? " [" + filter + "]" : ""))));
    }

    static final String[] SORT_NAMES = {"Giá cao nhất", "Giá thấp nhất", "Mới nhất"};

    // ===== AH GUI (VO HAN TRANG: hang that o cac trang dau, sau do la hang bot sinh theo so thu tu) =====
    static final int VPAGES = 1_000_000_000; // 1 ty trang

    static class AhGui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final UUID viewer; final String filter; int page, sort, realPages, total;
        List<Listing> real = new ArrayList<>();

        AhGui(int id, PlayerInventory pinv, SimpleInventory inv, UUID viewer, int page, String filter, int sort) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.viewer = viewer; this.page = page; this.filter = filter; this.sort = sort;
            refresh();
        }

        boolean bots() { return Admin.on("bots"); }

        Listing at(int pg, int i) {
            if (pg < realPages) {
                int idx = pg * PER_PAGE + i;
                return idx < real.size() ? real.get(idx) : null;
            }
            if (!bots()) return null;
            long v = (long) (pg - realPages) * PER_PAGE + i;
            return FakeMarket.virtual(v, filter, sort);
        }

        void refresh() {
            real = new ArrayList<>();
            for (Listing l : LISTINGS) {
                if (filter != null) {
                    String n = l.stack.getName().getString().toLowerCase();
                    String idp = Registries.ITEM.getId(l.stack.getItem()).getPath();
                    if (!n.contains(filter) && !idp.contains(filter.replace(' ', '_'))) continue;
                }
                real.add(l);
            }
            if (sort == 0) real.sort((a, b) -> Double.compare(b.price, a.price));
            else if (sort == 1) real.sort(Comparator.comparingDouble(a -> a.price));
            else real.sort((a, b) -> Long.compare(b.created, a.created));
            realPages = (real.size() + PER_PAGE - 1) / PER_PAGE;
            total = bots() ? realPages + VPAGES : Math.max(1, realPages);
            page = Math.max(0, Math.min(page, total - 1));

            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = 0; i < PER_PAGE; i++) {
                Listing l = at(page, i);
                if (l == null) continue;
                boolean own = l.seller.equals(viewer);
                ItemStack d = l.stack.copy();
                d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§eGiá: $" + DonutLike.fmt(l.price)),
                    Text.literal("§7Người bán: " + l.sellerName),
                    Text.literal(own ? "§cClick để huỷ bán" : "§aClick để mua"))));
                inv.setStack(i, d);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, named(Items.GRAY_STAINED_GLASS_PANE, " "));
            if (page > 0) inv.setStack(45, named(Items.ARROW, "§e← Trang trước", "§7Chuột phải: -100 trang", "§7Shift+trái: -10.000 | Shift+phải: -1.000.000"));
            inv.setStack(48, named(Items.HOPPER, "§bSắp xếp: " + SORT_NAMES[sort], "§7Click để đổi: giá cao nhất → giá thấp nhất → mới nhất", "§7Chính xác nhất khi lọc 1 vật phẩm: /ah <item>"));
            inv.setStack(50, mine() ? named(Items.COMPASS, "§aTất cả order", "§7Quay lại danh sách order chung")
                : named(Items.ENDER_CHEST, "§6Order của bạn", "§7Xem order bạn đã đặt", "§7Click vào order để §alấy đồ§7 đã được giao"));
            inv.setStack(49, named(Items.PAPER, "§fTrang " + String.format("%,d", (long) page + 1) + "/" + String.format("%,d", (long) total),
                "§7" + real.size() + " món của người chơi"));
            inv.setStack(50, named(Items.CHEST, "§6§lSell - đăng bán đồ", "§7Mở hộp đặt đồ, chỉnh giá rồi đăng lên /ah",
                "§7Đang đăng: §f" + countListings(viewer) + "/" + maxListings()));
            if (page < total - 1) inv.setStack(53, named(Items.ARROW, "§eTrang sau →", "§7Chuột phải: +100 trang", "§7Shift+trái: +10.000 | Shift+phải: +1.000.000"));
        }

        int step(int button, SlotActionType type) {
            if (type == SlotActionType.QUICK_MOVE) return button == 1 ? 1_000_000 : 10_000;
            return button == 1 ? 100 : 1;
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (slot >= 0 && slot < 54 && (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE) && player instanceof ServerPlayerEntity sp) {
                if (slot == 50) DonutLike.SERVER.execute(() -> openSellBox(sp));
                else if (slot == 45 && page > 0) reopen(sp, (int) Math.max(0L, (long) page - step(button, type)), sort);
                else if (slot == 53 && page < total - 1) reopen(sp, (int) Math.min((long) total - 1, (long) page + step(button, type)), sort);
                else if (slot == 48) reopen(sp, 0, (sort + 1) % 3);
                else if (slot < PER_PAGE) {
                    Listing l = at(page, slot);
                    if (l != null) click(sp, l);
                    refresh();
                }
            }
            syncState(); // chan moi thao tac keo tha
        }

        void reopen(ServerPlayerEntity sp, int pg, int so) {
            DonutLike.SERVER.execute(() -> openAh(sp, pg, filter, so));
        }

        void click(ServerPlayerEntity sp, Listing l) {
            if (l.bot) {
                if (FakeMarket.SOLD.contains(l.vid)) { DonutLike.msg(sp, "§cMón này vừa bị mua."); return; }
                if (DonutLike.bal(sp.getUuid()) < l.price) { DonutLike.msg(sp, "§cBạn không đủ tiền ($" + DonutLike.fmt(l.price) + ")."); return; }
                if (!ShopHandler.canReceiveStack(sp, l.stack)) return;
                FakeMarket.SOLD.add(l.vid);
                DonutLike.add(sp.getUuid(), -l.price);
                sp.getInventory().offerOrDrop(l.stack.copy());
                ShopHandler.ting(sp);
                DonutLike.msg(sp, "§aĐã mua " + l.stack.getName().getString() + " với giá $" + DonutLike.fmt(l.price));
                return;
            }
            if (!LISTINGS.contains(l)) { DonutLike.msg(sp, "§cMón này vừa bị mua/huỷ."); return; }
            if (l.seller.equals(sp.getUuid())) {
                if (!ShopHandler.canReceiveStack(sp, l.stack)) return;
                LISTINGS.remove(l);
                sp.getInventory().offerOrDrop(l.stack);
                DonutLike.msg(sp, "§eĐã huỷ bán, vật phẩm đã trả lại.");
            } else if (DonutLike.bal(sp.getUuid()) < l.price) {
                DonutLike.msg(sp, "§cBạn không đủ tiền ($" + DonutLike.fmt(l.price) + ").");
            } else {
                if (!ShopHandler.canReceiveStack(sp, l.stack)) return;
                LISTINGS.remove(l);
                DonutLike.add(sp.getUuid(), -l.price);
                DonutLike.add(l.seller, l.price);
                ServerPlayerEntity seller = DonutLike.SERVER.getPlayerManager().getPlayer(l.seller);
                if (seller != null) DonutLike.msg(seller, "§a[AH] " + sp.getName().getString() + " đã mua "
                    + l.stack.getName().getString() + " với giá $" + DonutLike.fmt(l.price));
                sp.getInventory().offerOrDrop(l.stack);
                DonutLike.msg(sp, "§aĐã mua " + l.stack.getName().getString() + " với giá $" + DonutLike.fmt(l.price));
            }
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    // ===== SELL BOX (trong /ah): dat do vao o, chinh gia bang nut, bam dang ban =====
    static void openSellBox(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new SellBox(id, inv, new SimpleInventory(36)), Text.literal("Sell - đặt đồ vào ô trên cùng")));
    }

    static class SellBox extends GenericContainerScreenHandler {
        static final int ITEM = 4;
        final SimpleInventory inv;
        final UUID owner;
        double price = 100;
        boolean touched = false;

        SellBox(int id, PlayerInventory pinv, SimpleInventory inv) {
            super(ScreenHandlerType.GENERIC_9X4, id, pinv, inv, 4);
            this.inv = inv;
            this.owner = pinv.player.getUuid();
            for (int i = 0; i < 36; i++) if (i != ITEM) inv.setStack(i, named(Items.GRAY_STAINED_GLASS_PANE, " "));
            inv.setStack(ITEM, ItemStack.EMPTY);
            refresh();
        }

        void refresh() {
            ItemStack it = inv.getStack(ITEM);
            if (!touched && !it.isEmpty()) {
                double fair = Prices.stack(it);
                if (fair > 0) price = Math.max(0.01, Math.round(fair * 100.0) / 100.0);
            }
            inv.setStack(3, named(Items.ARROW, "§7Đặt vật phẩm vào ô bên phải →", "§7Click ô đó với đồ trên tay, hoặc Shift+click đồ trong túi"));
            inv.setStack(9, named(Items.RED_WOOL, "§c÷10"));
            inv.setStack(10, named(Items.RED_WOOL, "§c-1K"));
            inv.setStack(11, named(Items.RED_WOOL, "§c-100"));
            inv.setStack(12, named(Items.RED_WOOL, "§c-10"));
            inv.setStack(13, named(Items.PAPER, "§eGiá: §a$" + Prices.money(price), "§7Dùng nút hai bên để chỉnh giá"));
            inv.setStack(14, named(Items.LIME_WOOL, "§a+10"));
            inv.setStack(15, named(Items.LIME_WOOL, "§a+100"));
            inv.setStack(16, named(Items.LIME_WOOL, "§a+1K"));
            inv.setStack(17, named(Items.LIME_WOOL, "§a×10"));
            inv.setStack(20, named(Items.BARRIER, "§c§lQuay lại /ah", "§7Đồ trong ô sẽ trả về túi"));
            inv.setStack(22, named(Items.GREEN_WOOL, "§2§lĐĂNG BÁN", "§7Giá: §a$" + Prices.money(price),
                "§7Bot hoặc người chơi khác có thể mua"));
            inv.setStack(24, named(Items.CHEST, "§fĐang đăng: §e" + countListings(owner) + "/" + maxListings()));
        }

        void adjust(int slot) {
            touched = true;
            switch (slot) {
                case 9 -> price = Math.max(0.01, price / 10);
                case 10 -> price -= 1000;
                case 11 -> price -= 100;
                case 12 -> price -= 10;
                case 14 -> price += 10;
                case 15 -> price += 100;
                case 16 -> price += 1000;
                case 17 -> price = Math.min(1e36, price * 10);
                default -> { }
            }
            price = Math.max(0.01, Math.round(price * 100.0) / 100.0);
        }

        void list(ServerPlayerEntity sp) {
            ItemStack st = inv.getStack(ITEM);
            if (st.isEmpty()) { DonutLike.msg(sp, "§cHãy đặt vật phẩm vào ô trên cùng trước."); return; }
            if (countListings(sp.getUuid()) >= maxListings()) { DonutLike.msg(sp, "§cBạn chỉ được đăng tối đa " + maxListings() + " món cùng lúc."); return; }
            LISTINGS.add(new Listing(sp.getUuid(), sp.getName().getString(), st.copy(), price));
            inv.setStack(ITEM, ItemStack.EMPTY);
            ShopHandler.ting(sp);
            DonutLike.msg(sp, "§aĐã đăng bán lên /ah giá $" + DonutLike.fmt(price) + " §7(" + countListings(sp.getUuid()) + "/" + maxListings() + ")");
            DonutLike.SERVER.execute(() -> openAh(sp, 0, null, 0));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (!(player instanceof ServerPlayerEntity sp)) return;
            if (slot >= 36 && slot < this.slots.size()) {                 // tui do cua nguoi choi
                if (type == SlotActionType.PICKUP) super.onSlotClick(slot, button, type, player);
                else if (type == SlotActionType.QUICK_MOVE) {
                    Slot s = this.slots.get(slot);
                    if (s.hasStack() && inv.getStack(ITEM).isEmpty()) {
                        inv.setStack(ITEM, s.getStack().copy());
                        s.setStack(ItemStack.EMPTY);
                    }
                }
            } else if (slot == ITEM) {                                     // o dat do
                if (type == SlotActionType.PICKUP) super.onSlotClick(slot, button, type, player);
                else if (type == SlotActionType.QUICK_MOVE && !inv.getStack(ITEM).isEmpty())
                    sp.getInventory().offerOrDrop(inv.removeStack(ITEM));
            } else if (slot >= 0 && slot < 36 && type == SlotActionType.PICKUP) {
                if (slot == 20) { DonutLike.SERVER.execute(() -> openAh(sp, 0, null, 0)); }
                else if (slot == 22) list(sp);
                else adjust(slot);
            }
            refresh();
            syncState();
        }

        @Override
        public void onClosed(PlayerEntity player) {
            ItemStack s = inv.removeStack(ITEM);
            if (!s.isEmpty()) player.getInventory().offerOrDrop(s);
            super.onClosed(player);
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    // ===== ORDER GUI (order cua nguoi choi that + order cua bot) =====
    static class OrderGui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final UUID viewer; final String filter; int page, pages, realPages, sort;
        List<Object> view = new ArrayList<>(); // Order (nguoi choi) hoac FakeMarket.FO (bot)
        List<net.minecraft.item.Item> vpool = new ArrayList<>(); // item khop bo loc -> order ao toi 10.000 trang

        OrderGui(int id, PlayerInventory pinv, SimpleInventory inv, UUID viewer, int page, String filter, int sort) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.viewer = viewer; this.page = page; this.filter = filter; this.sort = sort;
            refresh();
        }

        boolean mine() { return "@me".equals(filter); }
        boolean noFilter() { return filter == null || filter.isEmpty() || mine(); }

        boolean match(net.minecraft.item.Item it) {
            if (noFilter()) return true;
            String idp = Registries.ITEM.getId(it).getPath();
            return idp.contains(filter.replace(' ', '_')) || new ItemStack(it).getName().getString().toLowerCase().contains(filter);
        }

        static double per(Object o) { return o instanceof Order r ? r.perItem : ((FakeMarket.FO) o).per; }
        static long created(Object o) { return o instanceof Order r ? r.created : 0L; }

        /** Muc o trang pg, vi tri i (null = trong). Cac trang dau la order that/bot co dinh, sau do la order ao cua item dang loc. */
        Object at(int pg, int i) {
            if (pg < realPages) {
                int idx = pg * PER_PAGE + i;
                return idx < view.size() ? view.get(idx) : null;
            }
            if (vpool.isEmpty()) return null;
            return FakeMarket.virtualOrder(vpool, (long) (pg - realPages) * PER_PAGE + i, sort);
        }

        void refresh() {
            view = new ArrayList<>();
            vpool = new ArrayList<>();
            for (Order o : ORDERS) {
                if (mine() ? !o.buyer.equals(viewer) : (o.remaining <= 0 && !o.buyer.equals(viewer))) continue;
                if (match(o.template.getItem())) view.add(o);
            }
            if (Admin.on("bots") && !mine()) {
                if (noFilter()) { FakeMarket.ensure(); view.addAll(FakeMarket.LIST); }
                else vpool = FakeMarket.matching(filter);
            }
            if (sort == 0) view.sort((a, b) -> Double.compare(per(b), per(a)));
            else if (sort == 1) view.sort((a, b) -> Double.compare(per(a), per(b)));
            else view.sort((a, b) -> Long.compare(created(b), created(a)));
            realPages = (view.size() + PER_PAGE - 1) / PER_PAGE;
            int vPages = vpool.isEmpty() ? 0 : FakeMarket.VORDER_PAGES;
            pages = Math.max(1, realPages + vPages);
            page = Math.max(0, Math.min(page, pages - 1));
            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = 0; i < PER_PAGE; i++) {
                Object ob = at(page, i);
                if (ob == null) continue;
                ItemStack d;
                if (ob instanceof Order o) {
                    boolean own = o.buyer.equals(viewer);
                    d = o.template.copyWithCount((int) Math.max(1L, Math.min(o.remaining, (long) o.template.getMaxCount())));
                    d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                        Text.literal("§eGiá mua: §a$" + DonutLike.fmt(o.perItem) + "§e /cái"),
                        Text.literal("§7Còn cần: §f" + num(o.remaining)),
                        Text.literal(own ? "§7Đã giao (trong order): §f" + num(o.stored) : "§7Người đặt: " + o.buyerName),
                        Text.literal(own ? "§aClick: lấy đồ về túi" : "§aClick để giao hàng (lấy từ túi bạn)"),
                        Text.literal(own ? "§cShift+click: huỷ order (hoàn tiền phần chưa giao)" : "§7Giao xong nhận tiền ngay"))));
                } else {
                    FakeMarket.FO o = (FakeMarket.FO) ob;
                    d = o.ench ? Enchants.full(o.item) : new ItemStack(o.item, 1); // luon hien 1 (so can giao nam o lore)
                    d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                        Text.literal((o.ench ? "§b★ Cần đồ FULL phù phép  " : "") + "§eGiá mua: §a$" + DonutLike.fmt(o.per) + "§e /cái"),
                        Text.literal("§7Còn cần: §f" + o.remaining),
                        Text.literal("§7Người đặt: " + o.name),
                        Text.literal("§aClick: giao 1 stack §7| §aShift+click: giao tối đa"))));
                }
                inv.setStack(i, d);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, named(Items.GRAY_STAINED_GLASS_PANE, " "));
            if (page > 0) inv.setStack(45, named(Items.ARROW, "§e← Trang trước", "§7Chuột phải: -100 trang", "§7Shift+trái: -10.000 | Shift+phải: -1.000.000"));
            inv.setStack(48, named(Items.HOPPER, "§bSắp xếp: " + SORT_NAMES[sort], "§7Click để đổi: giá cao nhất → giá thấp nhất → mới nhất"));
            inv.setStack(49, named(Items.PAPER, "§fTrang " + String.format("%,d", page + 1) + "/" + String.format("%,d", pages),
                "§7" + view.size() + " order" + (vpool.isEmpty() ? "" : " + order của bot (tới " + String.format("%,d", FakeMarket.VORDER_PAGES) + " trang)"),
                "§7/order <vật phẩm> để lọc | /order page <số> [item] để nhảy trang", "§7Tạo: /orders create <item> <sl> <giá/cái>"));
            if (page < pages - 1) inv.setStack(53, named(Items.ARROW, "§eTrang sau →", "§7Chuột phải: +100 trang", "§7Shift+trái: +10.000 | Shift+phải: +1.000.000"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (slot >= 0 && slot < 54 && (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE) && player instanceof ServerPlayerEntity sp) {
                int st = type == SlotActionType.QUICK_MOVE ? (button == 1 ? 1_000_000 : 10_000) : button == 1 ? 100 : 1;
                if (slot == 45 && page > 0) { int pg = (int) Math.max(0L, (long) page - st); DonutLike.SERVER.execute(() -> openOrders(sp, pg, filter, sort)); }
                else if (slot == 53 && page < pages - 1) { int pg = (int) Math.min((long) pages - 1, (long) page + st); DonutLike.SERVER.execute(() -> openOrders(sp, pg, filter, sort)); }
                else if (slot == 48) { int so = (sort + 1) % 3; DonutLike.SERVER.execute(() -> openOrders(sp, 0, filter, so)); }
                else if (slot == 50) { String f = mine() ? null : "@me"; DonutLike.SERVER.execute(() -> openOrders(sp, 0, f, sort)); }
                else if (slot < PER_PAGE) {
                    Object ob = at(page, slot);
                    if (ob != null) {
                        if (ob instanceof Order o) click(sp, o, type == SlotActionType.QUICK_MOVE);
                        else FakeMarket.sell(sp, (FakeMarket.FO) ob, type == SlotActionType.QUICK_MOVE);
                    }
                    refresh();
                }
            }
            syncState();
        }

        void click(ServerPlayerEntity sp, Order o, boolean shift) {
            if (!ORDERS.contains(o)) { DonutLike.msg(sp, "§cOrder này không còn."); return; }
            if (o.buyer.equals(sp.getUuid())) {
                if (shift) { // huy: hoan tien phan chua giao, do da giao van nam trong order de lay
                    double refund = o.perItem * o.remaining;
                    o.remaining = 0;
                    DonutLike.add(sp.getUuid(), refund);
                    DonutLike.msg(sp, "§eĐã huỷ order, hoàn $" + DonutLike.fmt(refund) + (o.stored > 0 ? " §7(còn " + num(o.stored) + " món chưa lấy - click để lấy)" : ""));
                    if (o.stored <= 0) ORDERS.remove(o);
                } else collect(sp, o);
                return;
            }
            if (o.remaining <= 0) { DonutLike.msg(sp, "§cOrder này đã đủ hàng."); return; }
            long need = o.remaining, given = 0;
            PlayerInventory pi = sp.getInventory();
            for (int i = 0; i < 36 && given < need; i++) {
                ItemStack s = pi.getStack(i);
                if (s.isEmpty() || !ItemStack.areItemsAndComponentsEqual(s, o.template)) continue;
                int n = (int) Math.min((long) s.getCount(), need - given);
                s.decrement(n);
                given += n;
            }
            if (given == 0) { DonutLike.msg(sp, "§cBạn không có vật phẩm phù hợp trong túi."); return; }
            double pay = o.perItem * given;
            DonutLike.add(sp.getUuid(), pay);
            o.remaining -= given;
            o.stored += given;                       // do nam trong order, chu order tu lay
            ShopHandler.ting(sp);
            DonutLike.msg(sp, "§a[Order] Đã giao " + num(given) + "x " + o.template.getName().getString() + ", nhận $" + DonutLike.fmt(pay));
            ServerPlayerEntity buyer = DonutLike.SERVER.getPlayerManager().getPlayer(o.buyer);
            if (buyer != null && Settings.on(buyer.getUuid(), "trade"))
                DonutLike.msg(buyer, "§a[Order] " + sp.getName().getString() + " đã giao " + num(given) + "x " + o.template.getName().getString()
                    + (o.remaining > 0 ? " (còn " + num(o.remaining) + ")" : " — order hoàn tất") + " §7→ /orders → Order của bạn để lấy đồ");
        }

        /** Chu order lay do da duoc giao ve tui (toi da theo cho trong tui). */
        void collect(ServerPlayerEntity sp, Order o) {
            if (o.stored <= 0) { DonutLike.msg(sp, "§7Chưa có đồ nào được giao. §8(Shift+click để huỷ order)"); return; }
            long n = Math.min(o.stored, (long) ShopHandler.spaceFor(sp, o.template));
            if (n <= 0) { DonutLike.msg(sp, "§cTúi đồ đầy! Hãy dọn chỗ trống rồi lấy tiếp."); return; }
            int max = Math.max(1, o.template.getMaxCount());
            long left = n;
            while (left > 0) {
                int c = (int) Math.min((long) max, left);
                sp.getInventory().offerOrDrop(o.template.copyWithCount(c));
                left -= c;
            }
            o.stored -= n;
            if (o.remaining <= 0 && o.stored <= 0) ORDERS.remove(o);
            ShopHandler.ting(sp);
            DonutLike.msg(sp, "§a[Order] Đã lấy " + num(n) + "x " + o.template.getName().getString()
                + (o.stored > 0 ? " §7(còn " + num(o.stored) + " trong order)" : ""));
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
